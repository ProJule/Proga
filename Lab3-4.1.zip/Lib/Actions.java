package Lib;

import Lib.Sub.Character;
import Lib.Sub.*;

import java.util.ArrayList;
import java.util.List;

public class Actions {
    public static void go() {

        Character neznayka = new Neznayka();
        Character kozlik = new Kozlik();
        Gostinica gostinica = new Gostinica();

        String[] Eats = {" чмокает", " жмурится", " расхваливает", " крякает", " уплетает"};
        String[] food = {" перловый суп", " пироги", " гречневая каша с маслом"};

        System.out.println(kozlik.getName() + ((Going) kozlik).doing());
        System.out.println(neznayka.getName() + ((Going) neznayka).doing());

        List<Character> clients = new ArrayList<>();
        clients.add(neznayka);
        clients.add(kozlik);


        if (((Neznayka) neznayka).isFoodles(neznayka)) {
            System.out.println(neznayka.getName() + " с аппетитом " + Eats[4] + food[0] + food[1] + food[2] + ". " + neznayka.getName() + Eats[2] + food[0] + food[1] + food[2]);
            if (((Kozlik) kozlik).isFoodles(kozlik)) {
                System.out.println(kozlik.getName() + " с аппетитом " + Eats[4] + food[0] + food[1] + food[2] + ". " + kozlik.getName() + Eats[0] + Eats[1] + Eats[3]);
            } else {
                System.out.println(kozlik.getName() + " немного ест" + food[1]);
            }
        } else {
            System.out.println(neznayka.getName() + " немного ест" + food[1]);
            if (((Kozlik) kozlik).isFoodles(kozlik)) {
                System.out.println(kozlik.getName() + " с аппетитом " + Eats[4] + food[0] + food[1] + food[2] + ". " + kozlik.getName() + Eats[0] + Eats[1] + Eats[3]);
            } else {
                System.out.println(kozlik.getName() + Eats[4] + food[1]);
            }
        }

        try {
            boolean lucky = ((Kozlik) kozlik).isLucky(kozlik);
        } catch (InvalidParameter e) {
            System.out.println("Ошибка параметров: " + e.getMessage());
       }

        try {
            boolean lucky = ((Neznayka) neznayka).isLucky(neznayka);
        } catch (InvalidParameter e) {
            System.out.println("Ошибка параметров: " + e.getMessage());
        }



        if (((Neznayka) neznayka).isSleeples(neznayka)) {
            System.out.println("\n" + neznayka.getName() + "хочет спать");
        } else {
            System.out.println("\n" +neznayka.getName() + "не хочет спать");
        }
        if (((Kozlik) kozlik).isSleeples(kozlik)) {
            System.out.println(kozlik.getName() + " хочет спать");
        } else {
            System.out.println(kozlik.getName() + " не хочет спать");
        }

        System.out.println(neznayka.getName()+ " " + kozlik.getName()+ " подходит к гостинице " + gostinica.getType());


        if(gostinica.addAvailableRooms(clients)){

            System.out.println();

        }else{
            System.out.println("Незнайка и Козлик ночуют на улице");
        }
    }

}
