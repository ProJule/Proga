package Lib.Sub;
import java.util.*;

public class Gostinica {
    private TypeGost type;
    private int availableRooms;
    private List<Room> rooms = new ArrayList<>();
    String[] furniture = {" стол", " кровати", " стулья", " шкаф", " рукомойник с зеркалом", " телевизор", " холодильник"};

    public Gostinica () {
        this.type = TypeGost.Ekonom;
        this.generateAvailableRooms();
    }

    public void setType(TypeGost type) {
        this.type = type;
    }

    public TypeGost getType() {
        return type;
    }


    public void generateAvailableRooms() {
        this.availableRooms = (int) (Math.random() * 100 + 1);
        if (availableRooms <= 0){
            try {
                throw new NoRooms(" Нет свободных комнат");
            } catch (NoRooms e) {
                throw new RuntimeException(e);
            }
        }
        int d = (int)(Math.random()*availableRooms);
        boolean isGood = Math.random() < 0.5;
        rooms.add(new Room("Комната №" + d, (int) (Math.random() * 40) + 1, isGood));
    }

    public boolean addAvailableRooms(List<Character> client) {
        if(client.size() <= availableRooms) {
            int priceChs = 0;
            for(Character chrt: client) {
                priceChs += chrt.getSantiki();
            }

            for(Room rm: this.rooms) {
                System.out.println("У персонажей " + priceChs + ". Самый дешёвый номер стоит " + rm.price() );
                if(priceChs >= rm.price()){
                    this.availableRooms = availableRooms - 1;
                    System.out.println("В " + (rm.isGood() ? "хороший" : "плохой") + " комнате");
                    System.out.println("Персонажи в " + rm.description());
                    if (rm.isGood()) {
                        System.out.print("В комнате есть");
                        for (String s : furniture) {
                            System.out.print(s);
                        }
                    }else{
                        System.out.print("В комнате есть ");
                        for (int i = 0; i < furniture.length - 4; i++) {
                            System.out.print(furniture[i]);
                        }
                    }
                    System.out.println("\nПерсонажи ложаться спать" + furniture[1]);
                    return true;
                }
            }
            return false;
        }
        return false;
    }

    public int getAvailableRooms() {
        return availableRooms;
    }



    public List<Room> getRooms() {
        return this.rooms;
    }

    public void addRoom(String description, int price) {
        this.rooms.add(new Room(description, price, true));
    }

}


