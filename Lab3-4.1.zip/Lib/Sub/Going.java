package Lib.Sub;

public interface Going {
    String doing();
}
