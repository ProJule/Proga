package Lib.Sub;

public class NoRooms extends Exception {
    public NoRooms(String message) {
        super(message);
    }
}