package Lib.Sub;

public abstract class Character {
    private String name;
    private int foodles;        //сытость
    private int sleeples; //усталость
    private int santiki;
    private int lucky;

    public Character() {
        this.name = "Объект типа персонаж";
        this.foodles = 0;
        this.sleeples = 50;
        this.lucky = 0;
    }

    public final String getName(){
        return this.name;
    }
    public final String setName(String n){
        this.name = n;
        return n;
    }
    public int getFoodles(){
        return this.foodles;
    }
    public void setFoodles(int f){
        this.foodles = f;
    }
    public int getLucky(){
        return this.lucky;
    }
    public void setLucky(int f){
        this.lucky = f;
    }
    public int getSleeples(){
        return this.sleeples;
    }
    public void setSleeples(int f){
        this.sleeples = f;
    }
    public int getSantiki(){
        return this.santiki;
    }
    public void setSantiki(int f){
        this.santiki = f;
    }
    @Override
    public String toString(){
        return this.name;
    }

    @Override
    public int hashCode(){
        return this.foodles;
    }



    @Override
    public boolean equals(Object o){
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Character character = (Character) o;
        return foodles == character.foodles;
    }
}