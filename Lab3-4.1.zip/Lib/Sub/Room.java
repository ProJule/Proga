package Lib.Sub;


public record Room(String description, int price, boolean isGood) {


    @Override
    public String toString() {
        return description + ", цена: " + price + ", " + (isGood ? "хороший" : "плохой");
    }

    @Override
    public int price() {
        return price;
    }

    @Override
    public boolean isGood() {
        return isGood;
    }
}

