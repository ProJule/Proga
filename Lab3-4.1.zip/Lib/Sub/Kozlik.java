package Lib.Sub;


public class Kozlik extends Character implements Going {
    public Kozlik() {
        super.setName("Козлик");
        super.setFoodles((int) (Math.random() * 30 + 1));
        super.setSleeples((int) (Math.random() * 100 + 1));
        super.setSantiki((int) (Math.random() * 50 + 1));
        super.setLucky((int) (Math.random() * 120 + 1));
    }

    @Override
    public String doing() {
        return " идёт в столовую";
    }

    public boolean isFoodles(Character a) {
        if (a.getFoodles() >= 0 & a.getFoodles() < 20) {
            System.out.println('\n' + a.getName() + " очень голодный");
            a.setFoodles(100);
            return true;
        } else {
            System.out.println("\n" + a.getName() + " не голодный");
            a.setFoodles(50);
            return false;
        }
    }

    public boolean isSleeples(Character a) {
        if (a.getSleeples() >= 50) {
            return true;
        } else {
            return false;
        }
    }

    public boolean isLucky(Character a) {
        if (a.getLucky() < 0 || a.getLucky() > 100) {
            throw new InvalidParameter("Некорректное значение lucky у персонажей " + a.getName());
        }
        if (a.getLucky() >= 50) {
            System.out.println("\n" + a.getName() +" находит сантики");
            a.setSantiki(a.getSantiki() + 10);
            System.out.println("у " +  a.getName() +" " + a.getSantiki() +" сантиков");
            return true;
        } else {
            if (a.getSantiki() <= 10) {
                a.setSantiki(0);
            } else {
                a.setSantiki(a.getSantiki() - 10);
            }
            return false;
        }
    }
}
