package Lib.Sub;

public enum TypeGost {
    Lux("Эксклюзив"),
    Norm("Стабильная"),
    Ekonom("Экономическая");
    private String gost;
    TypeGost(String gost){
        this.gost = gost;
    }
}
